<?php
/**
 *
 * @author     RadiusTheme
 * @package    classified-listing/templates
 * @version    1.4.13
 */
?>
<div class="rtcl-chat-content-wrapper">
	<div id="rtcl-user-chat-wrap"></div> <!--JavaScript will take care of this div -->
</div>
