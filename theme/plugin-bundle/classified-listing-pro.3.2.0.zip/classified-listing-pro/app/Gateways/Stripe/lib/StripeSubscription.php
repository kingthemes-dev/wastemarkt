<?php

namespace RtclPro\Gateways\Stripe\lib;

class StripeSubscription {

	
	
	
}