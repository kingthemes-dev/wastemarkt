<?php
/**
 * @package ClassifiedListing/Templates
 * @version 1.2.31
 */

use RtclStore\Helpers\Functions as StoreFunctions;

defined('ABSPATH') || exit();
?>

<div <?php StoreFunctions::store_loop_start_class() ?>>
