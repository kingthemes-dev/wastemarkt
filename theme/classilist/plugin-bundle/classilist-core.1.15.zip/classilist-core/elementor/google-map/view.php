<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\ClassiList_Core;
?>
<div class="rt-el-google-map">
	<?php echo $data['iframe'];?>
</div>